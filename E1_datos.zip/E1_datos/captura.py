# Proyecto 2 PDS - Captura de un registro de 20 s desde la ESP32 a CSV
# Cambia NOMBRE y PWM antes de cada registro y ejecuta con el boton Play.
#   R1: NOMBRE = "R1.csv", PWM = 0
#   R2: NOMBRE = "R2.csv", PWM = 120   (tu PWM bajo)
#   R3: NOMBRE = "R3.csv", PWM = 255

# ====== CONFIGURA AQUI ======
PUERTO = "COM4"
NOMBRE = "R3.csv"
PWM = 255
# ============================

import serial, time, csv, os

DUR, FS = 20, 100
carpeta = os.path.dirname(os.path.abspath(__file__))
ruta = os.path.join(carpeta, NOMBRE)

ser = serial.Serial(PUERTO, 115200, timeout=1)
time.sleep(2)                      # la ESP32 se reinicia al abrir el puerto
ser.reset_input_buffer()

ser.write(f"{PWM}\n".encode())     # fija la velocidad del motor
print(f"Motor en PWM={PWM}, esperando 3 s a que se estabilice...")
time.sleep(3)
ser.reset_input_buffer()
ser.readline()                     # descarta una linea incompleta

print("Grabando 20 s, no toques la base...")
rows = []
while len(rows) < DUR * FS:
    line = ser.readline().decode(errors="ignore").strip()
    parts = line.split(",")
    if len(parts) == 2 and all(p.lstrip("-").isdigit() for p in parts):
        rows.append(parts)

ser.write(b"0\n")                  # apaga el motor
ser.close()

with open(ruta, "w", newline="") as f:
    f.write(f"# fs_nominal_Hz={FS}, eje=Z, rango=+-2g, sensibilidad=16384 LSB/g, PWM={PWM}\n")
    w = csv.writer(f)
    w.writerow(["timestamp_us", "az_raw_LSB"])
    w.writerows(rows)

print(f"Guardado {ruta}: {len(rows)} muestras")