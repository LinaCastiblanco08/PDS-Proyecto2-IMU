// Proyecto 2 PDS - Adquisicion IMU (MPU6050) + control de motor (L298N)
// ESP32. Muestrea el eje Z del acelerometro a 100 Hz y lo envia por Serial: "timestamp_us,az_raw"
// Para cambiar la velocidad del motor, enviar por Serial un numero 0-255 seguido de Enter.

#include <Wire.h>

const int ENA = 25;   // PWM del motor (quitar el jumper de ENA en el L298N)
const int IN1 = 26;
const int IN2 = 27;

const uint8_t MPU = 0x68;
const uint32_t Ts_us = 10000;   // 100 Hz
uint32_t tNext;
int pwm = 0;

void mpuWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

int16_t readAz() {
  Wire.beginTransmission(MPU);
  Wire.write(0x3F);               // ACCEL_ZOUT_H
  Wire.endTransmission(false);
  Wire.requestFrom(MPU, (uint8_t)2);
  return (int16_t)((Wire.read() << 8) | Wire.read());
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);             // SDA, SCL
  Wire.setClock(400000);

  mpuWrite(0x6B, 0x00);           // despertar el MPU6050
  mpuWrite(0x1C, 0x00);           // rango +-2 g -> 16384 LSB/g
  mpuWrite(0x1A, 0x00);           // DLPF interno minimo (~260 Hz)

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  digitalWrite(IN1, HIGH);        // sentido de giro fijo
  digitalWrite(IN2, LOW);
  analogWrite(ENA, 0);            // motor apagado al iniciar

  tNext = micros();
}

void loop() {
  if (Serial.available()) {
    String s = Serial.readStringUntil('\n');
    s.trim();
    if (s.length()) {
      pwm = constrain(s.toInt(), 0, 255);
      analogWrite(ENA, pwm);
    }
  }

  if ((int32_t)(micros() - tNext) >= 0) {
    tNext += Ts_us;
    uint32_t t = micros();
    int16_t az = readAz();
    Serial.print(t);
    Serial.print(',');
    Serial.println(az);
  }
}